import mongoose from "mongoose";

const postSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",   // Relación con la tabla usuarios
      required: true,
    },
    content: {
      type: String,
      required: true,
      trim: true,
    },
  },
  { timestamps: true }  // Crea createdAt y updatedAt automáticamente
);

const Post = mongoose.model("Post", postSchema);

export default Post;
