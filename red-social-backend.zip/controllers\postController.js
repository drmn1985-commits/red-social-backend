import mongoose from "mongoose";

// Crear un esquema simple para publicaciones
const publicacionSchema = new mongoose.Schema({
  titulo: { type: String, required: true },
  contenido: { type: String, required: true },
  autor: { type: String, required: true },
  fecha: { type: Date, default: Date.now }
});

const Publicacion = mongoose.model("Publicacion", publicacionSchema);

// Controladores
export const crearPublicacion = async (req, res) => {
  try {
    const publicacion = new Publicacion(req.body);
    await publicacion.save();
    res.json({ message: "Publicación creada", publicacion });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

export const obtenerPublicaciones = async (req, res) => {
  try {
    const publicaciones = await Publicacion.find();
    res.json(publicaciones);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};
